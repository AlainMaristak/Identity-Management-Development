<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login SSO</title>
</head>
<body>
    <h1>Bienvenido</h1>
    <p>Haga clic en el botón para iniciar sesión con SSO:</p>
    <!-- <form action="./lib/keycloak_login.php" method="GET"> -->
    <form action="./test/loginsso.php" method="GET">
        <button type="submit">Iniciar sesión con SSO</button>
    </form>
</body>
</html>
